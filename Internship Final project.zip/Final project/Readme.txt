Fantansy.db can be accessed through a sql studio
Other files are py files and the html files are designed in QT designer and converted to executable GUI's through Pyuic5
To view the project code go through the project code files.